<?php
// Isi kredensial database lokal/hosting di sini.
$dbHost = 'localhost';
$dbName = 'the_iv_drip_bali';
$dbUser = 'root';
$dbPass = '';

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    // Website publik tetap dapat menampilkan konten statis saat DB belum disiapkan.
    $pdo = null;
}
