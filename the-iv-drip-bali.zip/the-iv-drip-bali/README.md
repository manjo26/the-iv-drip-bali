# The IV Drip Bali — starter project

## Persyaratan lokal
- XAMPP dengan PHP 8.2 dan MySQL/MariaDB
- Browser modern
- VS Code (opsional)

## Menjalankan di XAMPP
1. Ekstrak folder `the-iv-drip-bali` ke `C:\xampp82\htdocs\`.
2. Jalankan Apache dan MySQL dari XAMPP Control Panel.
3. Buka phpMyAdmin: `http://localhost/phpmyadmin`.
4. Import file `database.sql`.
5. Periksa `config/database.php`. Default lokal XAMPP: user `root`, password kosong.
6. Buka `http://localhost/the-iv-drip-bali/`.
7. Buat admin melalui `http://localhost/the-iv-drip-bali/create-admin.php`.
8. Setelah admin dibuat, HAPUS `create-admin.php`.
9. Login di `http://localhost/the-iv-drip-bali/admin/login.php`.

## Catatan
- Ini adalah fondasi tahap pertama: homepage, filter paket, formulir WhatsApp, skema database, dan login admin dasar.
- Data paket, testimoni, dan klaim pada homepage merupakan bahan migrasi awal dari website lama; wajib dikonfirmasi pemilik sebelum tayang.
- Informasi layanan medis bukan nasihat medis. Klaim izin, lisensi, sertifikasi, FDA/ISO, hasil, dan statistik tidak boleh dipublikasikan sebelum diverifikasi.
- Nomor WhatsApp dan email saat ini disalin dari website sumber dan perlu dikonfirmasi klien.
- Harga tidak ditampilkan pada halaman publik.
- Untuk produksi, gunakan HTTPS, ganti kredensial database, aktifkan backup, dan lindungi folder konfigurasi serta file setup.
- Modul CRUD dashboard, manajemen gambar, bilingual, halaman privasi/syarat, dan SEO teknis akan dikembangkan berikutnya.
