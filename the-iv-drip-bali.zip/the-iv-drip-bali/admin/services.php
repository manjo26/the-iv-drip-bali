
<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$stmt = $pdo->query("
    SELECT *
    FROM services
    ORDER BY sort_order ASC, id DESC
");

$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Layanan - THE IV DRIP BALI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            THE IV DRIP BALI · ADMIN
        </a>
        <a href="logout.php" class="btn btn-outline-light btn-sm">
            Logout
        </a>
    </div>
</nav>

<div class="container py-5">

    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
        <div>
            <h3 class="fw-bold">Kelola Layanan</h3>
            <p class="text-muted mb-0">
                Kelola foto, ikon, dan informasi layanan website.
            </p>
        </div>

        <a href="service-form.php" class="btn btn-primary">
            + Tambah Layanan
        </a>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Foto</th>
                            <th>Nama Layanan</th>
                            <th>Deskripsi</th>
                            <th>Icon</th>
                            <th>Status</th>
                            <th>Urutan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php if (count($services) > 0): ?>

                        <?php foreach ($services as $i => $service): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>

                            <td>
                                <?php if (!empty($service['image'])): ?>
                                    <img
                                        src="../<?= e($service['image']) ?>"
                                        alt="<?= e($service['title']) ?>"
                                        style="width:85px;height:65px;object-fit:cover;border-radius:8px;"
                                    >
                                <?php else: ?>
                                    <span class="text-muted small">
                                        Belum ada foto
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td class="fw-semibold">
                                <?= e($service['title']) ?>
                            </td>

                            <td style="min-width:180px">
                                <?= e($service['description']) ?>
                            </td>

                            <td><?= e($service['icon'] ?? '-') ?></td>

                            <td>
                                <?php if ($service['is_active']): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Nonaktif</span>
                                <?php endif; ?>
                            </td>

                            <td><?= (int)$service['sort_order'] ?></td>

                            <td>
                                <div class="d-flex gap-1">
                                    <a href="service-form.php?id=<?= (int)$service['id'] ?>"
                                       class="btn btn-warning btn-sm">
                                        Edit
                                    </a>

                                    <a href="service-delete.php?id=<?= (int)$service['id'] ?>"
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('Yakin ingin menghapus layanan ini?')">
                                        Hapus
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Belum ada data layanan.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <a href="index.php" class="btn btn-secondary">
                Kembali ke Dashboard
            </a>

        </div>
    </div>
</div>

</body>
</html>
