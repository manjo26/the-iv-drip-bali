
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->query('SELECT * FROM packages ORDER BY sort_order ASC, id DESC');
$packages = $stmt->fetchAll(PDO::FETCH_ASSOC);

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Paket IV | The IV Drip Bali</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar bg-white shadow-sm">
    <div class="container">
        <a href="index.php" class="navbar-brand fw-bold">THE IV DRIP BALI · ADMIN</a>
        <a href="logout.php" class="btn btn-outline-danger btn-sm">Keluar</a>
    </div>
</nav>

<main class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold">Paket IV</h1>
            <p class="text-secondary mb-0">Kelola daftar paket pada website.</p>
        </div>
        <a href="package-form.php" class="btn btn-primary">+ Tambah Paket</a>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Nama Paket</th>
                        <th>Kategori</th>
                        <th>Status</th>
                        <th>Urutan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$packages): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-secondary">
                            Belum ada paket IV.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($packages as $package): ?>
                    <tr>
                        <td class="fw-semibold"><?= e($package['name']) ?></td>
                        <td><?= e($package['category']) ?></td>
                        <td>
                            <?php if ($package['is_active']): ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Nonaktif</span>
                            <?php endif; ?>
                        </td>
                        <td><?= (int)$package['sort_order'] ?></td>
                        <td>
                            <a href="package-form.php?id=<?= (int)$package['id'] ?>"
                               class="btn btn-sm btn-outline-primary">Edit</a>
                            <a href="package-delete.php?id=<?= (int)$package['id'] ?>"
                               class="btn btn-sm btn-outline-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="index.php" class="btn btn-outline-secondary mt-4">← Kembali ke Dashboard</a>
</main>

</body>
</html>
