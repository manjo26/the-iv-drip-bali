
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$categories = ['Pemulihan', 'Hidrasi', 'Kekebalan', 'Energi'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$package = [
    'name' => '',
    'category' => 'Pemulihan',
    'description' => '',
    'image' => '',
    'is_active' => 1,
    'sort_order' => 0
];

if ($id > 0) {
    $stmt = $pdo->prepare('SELECT * FROM packages WHERE id = ?');
    $stmt->execute([$id]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$existing) {
        exit('Paket tidak ditemukan.');
    }

    $package = $existing;
}

$error = '';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        exit('Permintaan tidak valid. Silakan muat ulang halaman.');
    }

    $name = trim($_POST['name'] ?? '');
    $category = $_POST['category'] ?? '';
    $description = trim($_POST['description'] ?? '');
    $sortOrder = filter_var($_POST['sort_order'] ?? 0, FILTER_VALIDATE_INT);
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $image = $package['image'];

    if ($name === '' || $description === '') {
        $error = 'Nama paket dan deskripsi wajib diisi.';
    } elseif (!in_array($category, $categories, true)) {
        $error = 'Kategori tidak valid.';
    } elseif ($sortOrder === false) {
        $error = 'Urutan harus berupa angka bulat.';
    } elseif (mb_strlen($name) > 160) {
        $error = 'Nama paket maksimal 160 karakter.';
    } else {
        $newImagePath = null;

        if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                $error = 'Upload gambar gagal. Coba kembali.';
            } elseif ($_FILES['image']['size'] > 3 * 1024 * 1024) {
                $error = 'Ukuran gambar maksimal 3 MB.';
            } else {
                $tmpFile = $_FILES['image']['tmp_name'];
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($tmpFile);

                $allowedTypes = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/webp' => 'webp'
                ];

                if (!isset($allowedTypes[$mime])) {
                    $error = 'Format gambar harus JPG, PNG, atau WEBP.';
                } else {
                    $uploadDir = __DIR__ . '/../assets/uploads/packages/';

                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }

                    $filename = bin2hex(random_bytes(16)) . '.' . $allowedTypes[$mime];
                    $destination = $uploadDir . $filename;

                    if (move_uploaded_file($tmpFile, $destination)) {
                        $newImagePath = 'assets/uploads/packages/' . $filename;
                        $image = $newImagePath;
                    } else {
                        $error = 'Gambar tidak berhasil disimpan.';
                    }
                }
            }
        }

        if ($error === '') {
            try {
                if ($id > 0) {
                    $stmt = $pdo->prepare(
                        'UPDATE packages
                         SET name = ?, category = ?, description = ?,
                             image = ?, is_active = ?, sort_order = ?
                         WHERE id = ?'
                    );

                    $stmt->execute([
                        $name, $category, $description,
                        $image ?: null, $isActive, $sortOrder, $id
                    ]);
                } else {
                    $stmt = $pdo->prepare(
                        'INSERT INTO packages
                         (name, category, description, image, is_active, sort_order)
                         VALUES (?, ?, ?, ?, ?, ?)'
                    );

                    $stmt->execute([
                        $name, $category, $description,
                        $image ?: null, $isActive, $sortOrder
                    ]);
                }

                // Hapus gambar lama jika berhasil diganti.
                if ($newImagePath && !empty($package['image'])) {
                    $oldImage = basename($package['image']);
                    $oldPath = __DIR__ . '/../assets/uploads/packages/' . $oldImage;

                    if (is_file($oldPath)) {
                        unlink($oldPath);
                    }
                }

                header('Location: packages.php');
                exit;

            } catch (PDOException $ex) {
                $error = 'Data gagal disimpan. Periksa koneksi database.';
            }
        }
    }

    $package['name'] = $name;
    $package['category'] = $category;
    $package['description'] = $description;
    $package['sort_order'] = $sortOrder === false ? 0 : $sortOrder;
    $package['is_active'] = $isActive;
}

?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $id ? 'Edit' : 'Tambah' ?> Paket IV | The IV Drip Bali</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar bg-white shadow-sm">
    <div class="container">
        <a href="index.php" class="navbar-brand fw-bold">THE IV DRIP BALI · ADMIN</a>
        <a href="logout.php" class="btn btn-outline-danger btn-sm">Keluar</a>
    </div>
</nav>

<main class="container py-5" style="max-width: 850px">
    <h1 class="h3 fw-bold"><?= $id ? 'Edit Paket IV' : 'Tambah Paket IV' ?></h1>
    <p class="text-secondary">Lengkapi informasi paket di bawah ini.</p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Paket</label>
                    <input type="text" name="name" class="form-control"
                           maxlength="160" required value="<?= e($package['name']) ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Kategori</label>
                    <select name="category" class="form-select" required>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= e($category) ?>"
                                <?= $package['category'] === $category ? 'selected' : '' ?>>
                                <?= e($category) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Deskripsi</label>
                    <textarea name="description" class="form-control" rows="5"
                              required><?= e($package['description']) ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Gambar Paket</label>
                    <input type="file" name="image" class="form-control"
                           accept=".jpg,.jpeg,.png,.webp">
                    <small class="text-secondary">Format JPG, PNG, WEBP. Maksimal 3 MB.</small>

                    <?php if (!empty($package['image'])): ?>
                        <div class="mt-3">
                            <img src="../<?= e($package['image']) ?>"
                                 alt="Gambar paket" style="max-width:180px;border-radius:10px">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Urutan Tampilan</label>
                    <input type="number" name="sort_order" class="form-control"
                           value="<?= (int)$package['sort_order'] ?>">
                </div>

                <div class="form-check form-switch mb-4">
                    <input type="checkbox" name="is_active" class="form-check-input"
                           id="is_active" <?= $package['is_active'] ? 'checked' : '' ?>>
                    <label class="form-check-label" for="is_active">
                        Tampilkan paket di website
                    </label>
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan Paket
                </button>
                <a href="packages.php" class="btn btn-outline-secondary">Batal</a>
            </form>
        </div>
    </div>
</main>

</body>
</html>
