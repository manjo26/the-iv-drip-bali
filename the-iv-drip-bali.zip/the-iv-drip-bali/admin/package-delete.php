
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header('Location: packages.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM packages WHERE id = ?');
$stmt->execute([$id]);
$package = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$package) {
    header('Location: packages.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        exit('Permintaan tidak valid.');
    }

    $stmt = $pdo->prepare('DELETE FROM packages WHERE id = ?');
    $stmt->execute([$id]);

    // Hapus gambar milik paket jika tersimpan di folder upload.
    if (!empty($package['image'])) {
        $imageName = basename($package['image']);
        $imagePath = __DIR__ . '/../assets/uploads/packages/' . $imageName;

        if (is_file($imagePath)) {
            unlink($imagePath);
        }
    }

    header('Location: packages.php?deleted=1');
    exit;
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hapus Paket | The IV Drip Bali</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<main class="container py-5" style="max-width:600px">
    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <h1 class="h4 fw-bold text-danger">Konfirmasi Hapus Paket</h1>

            <p class="text-secondary mt-3">
                Apakah kamu yakin ingin menghapus paket berikut?
            </p>

            <h5><?= e($package['name']) ?></h5>
            <p class="text-secondary"><?= e($package['category']) ?></p>

            <div class="alert alert-warning">
                Paket yang dihapus tidak dapat dikembalikan.
            </div>

            <form method="POST">
                <input type="hidden" name="csrf_token"
                       value="<?= e($_SESSION['csrf_token']) ?>">

                <button type="submit" class="btn btn-danger">
                    Ya, Hapus Paket
                </button>

                <a href="packages.php" class="btn btn-outline-secondary">
                    Batal
                </a>
            </form>
        </div>
    </div>
</main>

</body>
</html>
