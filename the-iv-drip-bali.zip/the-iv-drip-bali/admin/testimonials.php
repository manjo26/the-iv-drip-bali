
<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$stmt = $pdo->query("
    SELECT *
    FROM testimonials
    ORDER BY sort_order ASC, id DESC
");

$testimonials = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Testimoni - THE IV DRIP BALI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            THE IV DRIP BALI · ADMIN
        </a>
        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
</nav>

<div class="container py-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold">Kelola Testimoni</h3>
            <p class="text-muted mb-0">Daftar ulasan pelanggan website.</p>
        </div>

        <a href="testimonial-form.php" class="btn btn-primary">
            + Tambah Testimoni
        </a>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Nama Pelanggan</th>
                            <th>Negara</th>
                            <th>Testimoni</th>
                            <th>Status</th>
                            <th>Urutan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php if (count($testimonials) > 0): ?>
                        <?php foreach ($testimonials as $i => $item): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td class="fw-semibold"><?= e($item['customer_name']) ?></td>
                            <td><?= e($item['country'] ?? '-') ?></td>
                            <td><?= e($item['content']) ?></td>
                            <td>
                                <?php if ($item['is_approved']): ?>
                                    <span class="badge bg-success">Disetujui</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Menunggu</span>
                                <?php endif; ?>
                            </td>
                            <td><?= (int)$item['sort_order'] ?></td>
                            <td>
                                <a href="testimonial-form.php?id=<?= (int)$item['id'] ?>"
                                   class="btn btn-warning btn-sm">Edit</a>

                                <a href="testimonial-delete.php?id=<?= (int)$item['id'] ?>"
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Yakin ingin menghapus testimoni ini?')">
                                    Hapus
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                Belum ada testimoni.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <a href="index.php" class="btn btn-secondary">
                Kembali ke Dashboard
            </a>
        </div>
    </div>
</div>

</body>
</html>
