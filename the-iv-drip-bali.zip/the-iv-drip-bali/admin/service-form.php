
<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$service = [
    'title' => '',
    'description' => '',
    'icon' => '',
    'image' => '',
    'is_active' => 1,
    'sort_order' => 0
];

if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM services WHERE id = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$data) {
        die('Data layanan tidak ditemukan.');
    }

    $service = array_merge($service, $data);
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        die('Permintaan tidak valid. Silakan muat ulang halaman.');
    }

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $icon = trim($_POST['icon'] ?? '');
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $sort_order = (int) ($_POST['sort_order'] ?? 0);
    $image = $service['image'] ?? '';

    if ($title === '') {
        $error = 'Nama layanan wajib diisi.';
    }

    // Proses upload foto jika ada file baru.
    if (
        $error === '' &&
        isset($_FILES['image']) &&
        $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE
    ) {
        $file = $_FILES['image'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $error = 'Upload foto gagal. Silakan coba kembali.';
        } elseif ($file['size'] > 5 * 1024 * 1024) {
            $error = 'Ukuran foto maksimal 5 MB.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file['tmp_name']);

            $allowed = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp'
            ];

            if (!isset($allowed[$mime])) {
                $error = 'Format foto harus JPG, PNG, atau WEBP.';
            } else {
                $uploadDir = __DIR__ . '/../uploads/services/';

                if (
                    !is_dir($uploadDir) &&
                    !mkdir($uploadDir, 0755, true)
                ) {
                    $error = 'Folder upload tidak dapat dibuat.';
                } else {
                    $filename = bin2hex(random_bytes(16))
                        . '.' . $allowed[$mime];

                    if (move_uploaded_file(
                        $file['tmp_name'],
                        $uploadDir . $filename
                    )) {
                        $image = 'uploads/services/' . $filename;
                    } else {
                        $error = 'Foto tidak berhasil disimpan.';
                    }
                }
            }
        }
    }

    if ($error === '') {
        if ($id > 0) {
            $stmt = $pdo->prepare("
                UPDATE services
                SET title = ?, description = ?, icon = ?,
                    image = ?, is_active = ?, sort_order = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $title,
                $description,
                $icon,
                $image,
                $is_active,
                $sort_order,
                $id
            ]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO services
                (title, description, icon, image, is_active, sort_order)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $title,
                $description,
                $icon,
                $image,
                $is_active,
                $sort_order
            ]);
        }

        header('Location: services.php');
        exit;
    }

    $service = [
        'title' => $title,
        'description' => $description,
        'icon' => $icon,
        'image' => $image,
        'is_active' => $is_active,
        'sort_order' => $sort_order
    ];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $id > 0 ? 'Edit' : 'Tambah' ?> Layanan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="card border-0 shadow-sm mx-auto" style="max-width:700px">
        <div class="card-body p-4">

            <h3 class="fw-bold mb-4">
                <?= $id > 0 ? 'Edit Layanan' : 'Tambah Layanan' ?>
            </h3>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token"
                       value="<?= e($_SESSION['csrf_token']) ?>">

                <div class="mb-3">
                    <label class="form-label">Nama Layanan</label>
                    <input type="text" name="title" class="form-control"
                           value="<?= e($service['title']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Deskripsi</label>
                    <textarea name="description" class="form-control"
                              rows="4"><?= e($service['description']) ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Foto Layanan</label>
                    <input type="file" name="image" id="image"
                           class="form-control"
                           accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
                    <small class="text-muted">
                        Format JPG, PNG, WEBP. Maksimal 5 MB.
                    </small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Preview Foto</label>
                    <div>
                        <img
                            id="imagePreview"
                            src="<?= !empty($service['image']) ? '../' . e($service['image']) : '' ?>"
                            alt="Preview foto layanan"
                            style="<?= !empty($service['image']) ? '' : 'display:none;' ?>width:180px;height:120px;object-fit:cover;border-radius:10px;"
                        >
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Icon (opsional)</label>
                    <input type="text" name="icon" class="form-control"
                           value="<?= e($service['icon']) ?>"
                           placeholder="Contoh: 💧">
                    <small class="text-muted">
                        Ikon tetap bisa digunakan jika tidak memakai foto.
                    </small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Urutan Tampilan</label>
                    <input type="number" name="sort_order"
                           class="form-control"
                           value="<?= (int)$service['sort_order'] ?>">
                </div>

                <div class="form-check form-switch mb-4">
                    <input type="checkbox" name="is_active"
                           class="form-check-input" id="active"
                           <?= $service['is_active'] ? 'checked' : '' ?>>
                    <label class="form-check-label" for="active">
                        Aktifkan layanan
                    </label>
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan Layanan
                </button>

                <a href="services.php" class="btn btn-secondary">
                    Kembali
                </a>
            </form>

        </div>
    </div>
</div>

<script>
document.getElementById('image').addEventListener('change', function () {
    const preview = document.getElementById('imagePreview');

    if (this.files && this.files[0]) {
        preview.src = URL.createObjectURL(this.files[0]);
        preview.style.display = 'block';
    }
});
</script>

</body>
</html>
