<?php
session_start();
require_once __DIR__ . '/../config/database.php';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $email=filter_var(trim($_POST['email'] ?? ''),FILTER_VALIDATE_EMAIL);
 $password=$_POST['password'] ?? '';
 if (!$pdo) $error='Database belum tersambung.';
 elseif (!$email || $password==='') $error='Email dan password wajib diisi.';
 else {
  $stmt=$pdo->prepare('SELECT id,name,password_hash FROM admins WHERE email=? LIMIT 1');
  $stmt->execute([$email]); $admin=$stmt->fetch();
  if ($admin && password_verify($password,$admin['password_hash'])) {
   session_regenerate_id(true); $_SESSION['admin_id']=$admin['id']; $_SESSION['admin_name']=$admin['name'];
   header('Location: index.php'); exit;
  } else $error='Email atau password tidak cocok.';
 }
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Login Admin</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light"><main class="container min-vh-100 d-flex align-items-center justify-content-center"><div class="card border-0 shadow-sm p-4" style="max-width:420px;width:100%"><h1 class="h4 fw-bold">The IV Drip Bali</h1><p class="text-secondary">Admin Dashboard</p><?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error,ENT_QUOTES,'UTF-8') ?></div><?php endif; ?><form method="post"><label class="form-label">Email</label><input class="form-control mb-3" type="email" name="email" required><label class="form-label">Password</label><input class="form-control mb-3" type="password" name="password" required><button class="btn btn-primary w-100">Masuk</button></form><a class="small mt-3" href="../index.php">Kembali ke website</a></div></main></body></html>
