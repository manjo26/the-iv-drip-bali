
<?php
session_start();

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$allowedSettings = [
    'site_name' => 'Nama Website',
    'whatsapp' => 'Nomor WhatsApp',
    'email' => 'Email',
    'service_hours' => 'Jam Layanan'
];

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            INSERT INTO site_settings (setting_key, setting_value)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");

        foreach ($allowedSettings as $key => $label) {
            $value = trim($_POST[$key] ?? '');
            $stmt->execute([$key, $value]);
        }

        $pdo->commit();
        $message = 'Pengaturan website berhasil disimpan.';
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = 'Gagal menyimpan pengaturan. Periksa tabel site_settings.';
    }
}

$stmt = $pdo->query("SELECT setting_key, setting_value FROM site_settings");
$rows = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$settings = [
    'site_name' => $rows['site_name'] ?? 'The IV Drip Bali',
    'whatsapp' => $rows['whatsapp'] ?? '6285738304853',
    'email' => $rows['email'] ?? 'infusionbali01@gmail.com',
    'service_hours' => $rows['service_hours'] ?? '24/7'
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pengaturan Website - THE IV DRIP BALI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">THE IV DRIP BALI · ADMIN</a>
        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
</nav>

<div class="container py-5">
    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <h3 class="fw-bold mb-2">Pengaturan Website</h3>
            <p class="text-secondary">Kelola informasi utama website.</p>

            <?php if ($message): ?>
                <div class="alert alert-success"><?= e($message) ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Website</label>
                    <input type="text" name="site_name" class="form-control"
                           value="<?= e($settings['site_name']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Nomor WhatsApp</label>
                    <input type="text" name="whatsapp" class="form-control"
                           value="<?= e($settings['whatsapp']) ?>" required>
                    <small class="text-muted">Gunakan kode negara, contoh 628123456789.</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control"
                           value="<?= e($settings['email']) ?>">
                </div>

                <div class="mb-4">
                    <label class="form-label">Jam Layanan</label>
                    <input type="text" name="service_hours" class="form-control"
                           value="<?= e($settings['service_hours']) ?>">
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan Pengaturan
                </button>

                <a href="index.php" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

</body>
</html>
