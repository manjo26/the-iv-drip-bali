
<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$totalPackages = (int)$pdo->query('SELECT COUNT(*) FROM packages')->fetchColumn();
$totalServices = (int)$pdo->query('SELECT COUNT(*) FROM services')->fetchColumn();
$totalTestimonials = (int)$pdo->query('SELECT COUNT(*) FROM testimonials')->fetchColumn();

$adminName = htmlspecialchars($_SESSION['admin_name'] ?? 'Admin', ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin | The IV Drip Bali</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">THE IV DRIP BALI · ADMIN</a>
        <a href="logout.php" class="btn btn-outline-danger btn-sm">Keluar</a>
    </div>
</nav>

<main class="container py-5">
    <h1 class="h3 fw-bold">Dashboard</h1>
    <p class="text-secondary">Selamat datang, <?= $adminName ?>.</p>

    <div class="row g-3 mt-3">
        <?php foreach ([
            'Paket IV' => $totalPackages,
            'Layanan' => $totalServices,
            'Testimoni' => $totalTestimonials
        ] as $label => $number): ?>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-4">
                <div class="text-secondary small"><?= $label ?></div>
                <div class="display-5 fw-bold"><?= $number ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <h2 class="h5 fw-bold mt-5 mb-3">Kelola Website</h2>

    <div class="row g-3">
        <div class="col-md-4">
            <a href="packages.php"
               class="card border-0 shadow-sm p-4 text-decoration-none text-dark h-100">
                <h5>📦 Paket IV</h5>
                <p class="text-secondary mb-0">Tambah, edit, dan hapus paket.</p>
            </a>
        </div>

        <div class="col-md-4">
            <a href="services.php"
               class="card border-0 shadow-sm p-4 text-decoration-none text-dark h-100">
                <h5>🩺 Layanan</h5>
                <p class="text-secondary mb-0">Tambah, edit, aktifkan, dan hapus layanan.</p>
            </a>
        </div>

        
<div class="col-md-4">
    <a href="settings.php"
       class="card border-0 shadow-sm p-4 text-decoration-none text-dark h-100">
        <h5>⚙️ Pengaturan Website</h5>
        <p class="text-secondary mb-0">
            Ubah nama website, WhatsApp, email, dan jam layanan.
        </p>
    </a>
</div>


        <a href="testimonials.php"
   class="card border-0 shadow-sm p-4 text-decoration-none text-dark h-100">
    <h5>⭐ Testimoni</h5>
    <p class="text-secondary mb-0">
        Tambah, edit, dan hapus testimoni pelanggan.
    </p>
</a>

    <a href="../index.php" class="btn btn-primary mt-4">Lihat Website</a>
</main>

</body>
</html>
