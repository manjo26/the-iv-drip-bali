
<?php
session_start();

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$customerName = '';
$country = '';
$content = '';
$isApproved = 0;
$sortOrder = 0;
$error = '';

if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM testimonials WHERE id = ?");
    $stmt->execute([$id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$item) {
        exit('Testimoni tidak ditemukan.');
    }

    $customerName = $item['customer_name'];
    $country = $item['country'] ?? '';
    $content = $item['content'];
    $isApproved = (int) $item['is_approved'];
    $sortOrder = (int) $item['sort_order'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = trim($_POST['customer_name'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $isApproved = isset($_POST['is_approved']) ? 1 : 0;
    $sortOrder = (int) ($_POST['sort_order'] ?? 0);

    if ($customerName === '' || $content === '') {
        $error = 'Nama pelanggan dan isi testimoni wajib diisi.';
    } else {
        if ($id > 0) {
            $stmt = $pdo->prepare("
                UPDATE testimonials
                SET customer_name = ?, country = ?, content = ?,
                    is_approved = ?, sort_order = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $customerName, $country, $content,
                $isApproved, $sortOrder, $id
            ]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO testimonials
                (customer_name, country, content, is_approved, sort_order)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $customerName, $country, $content,
                $isApproved, $sortOrder
            ]);
        }

        header('Location: testimonials.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $id ? 'Edit' : 'Tambah' ?> Testimoni</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">THE IV DRIP BALI · ADMIN</a>
        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
</nav>

<div class="container py-5">
    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <h3 class="fw-bold mb-4">
                <?= $id ? 'Edit Testimoni' : 'Tambah Testimoni' ?>
            </h3>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Pelanggan *</label>
                    <input type="text" name="customer_name"
                           class="form-control" required
                           value="<?= e($customerName) ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Negara</label>
                    <input type="text" name="country"
                           class="form-control"
                           value="<?= e($country) ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Isi Testimoni *</label>
                    <textarea name="content" class="form-control"
                              rows="5" required><?= e($content) ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Urutan Tampilan</label>
                    <input type="number" name="sort_order"
                           class="form-control"
                           value="<?= (int)$sortOrder ?>">
                </div>

                <div class="form-check mb-4">
                    <input type="checkbox" name="is_approved"
                           class="form-check-input" id="approved"
                           <?= $isApproved ? 'checked' : '' ?>>
                    <label class="form-check-label" for="approved">
                        Tampilkan di website publik
                    </label>
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan Testimoni
                </button>

                <a href="testimonials.php" class="btn btn-secondary">
                    Kembali
                </a>
            </form>
        </div>
    </div>
</div>

</body>
</html>
