CREATE DATABASE IF NOT EXISTS the_iv_drip_bali CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE the_iv_drip_bali;

CREATE TABLE admins (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE packages (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(160) NOT NULL,
 category ENUM('Pemulihan','Hidrasi','Kekebalan','Energi') NOT NULL DEFAULT 'Pemulihan',
 description TEXT NOT NULL,
 image VARCHAR(255) NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 sort_order INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE services (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(160) NOT NULL,
 description TEXT NOT NULL,
 icon VARCHAR(60) NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 sort_order INT NOT NULL DEFAULT 0
);

CREATE TABLE testimonials (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(100) NOT NULL,
 country VARCHAR(100) NULL,
 content TEXT NOT NULL,
 is_approved TINYINT(1) NOT NULL DEFAULT 0,
 sort_order INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE site_settings (
 setting_key VARCHAR(100) PRIMARY KEY,
 setting_value TEXT NULL
);

INSERT INTO site_settings (setting_key, setting_value) VALUES
('site_name','The IV Drip Bali'),
('whatsapp','6285738304853'),
('email','infusionbali01@gmail.com'),
('service_hours','24/7')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);
